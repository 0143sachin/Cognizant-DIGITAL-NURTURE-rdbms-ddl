ALTER TABLE PointofInterest add CONSTRAINT FK foreign key(townID)
references Town(townID);