alter table Buses 
add Ac_Available varchar2(10);