create table payments(
payment_ID    varchar2(3),
ticket_ID     varchar2(3),
BD_ID         number(11),
discount_ID   varchar2(3),
constraint PK_PAYMENTS primary key(payment_ID),
constraint FK_PAYMENTS_TICKETS foreign key(ticket_ID) references TICKETS(ticket_ID),
constraint FK_PAYMENTS_BOOKINGDETAILS foreign key(BD_ID) references BOOKINGDETAILS(BD_ID),
constraint FK_PAYMENTS_DISCOUNTS foreign key(discount_ID) references DISCOUNTS(discount_ID)
);