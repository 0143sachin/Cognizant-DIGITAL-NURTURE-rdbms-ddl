ALTER TABLE buses
MODIFY Ac_Available varchar(5);